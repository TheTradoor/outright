#!/usr/bin/env python3
import hashlib,json,os,re,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/scratch/31e010aaee78/program-integration')
OUT=Path('/workspace/scratch/31e010aaee78/supplemental-wrapper-results')
SBF=Path('/workspace/scratch/31e010aaee78/oracle-repair-after.so')
TARGET=sys.argv[1]
LOG=OUT/f'compile-{TARGET}.log'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
for line in LOG.read_text().splitlines():
 if line.startswith('{'):
  try: records.append(json.loads(line))
  except json.JSONDecodeError: pass
assert any(r.get('reason')=='build-finished' and r.get('success') for r in records)
name='percolator_prog' if TARGET=='library' else TARGET
bins=[r['executable'] for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and r.get('executable')]
assert len(bins)==1,bins
binary=bins[0]
out=OUT/TARGET;out.mkdir(exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.startswith(('PERCOLATOR_','PROPTEST_'))}
env['PERCOLATOR_FUZZ_SBF']=str(SBF)
listing=subprocess.check_output([binary,'--list','--format','terse'],cwd=ROOT,env=env,text=True)
(out/'list.txt').write_text(listing)
lines=[l for l in listing.splitlines() if l.strip()]
assert lines and all(l.endswith(': test') for l in lines),listing
names=sorted(l.removesuffix(': test') for l in lines)
assert len(names)==len(set(names))
report={'target':TARGET,'status':'incomplete','wrapper_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'candidate_tree':subprocess.check_output(['git','write-tree'],cwd=ROOT,text=True).strip(),'binary':binary,'binary_sha256':sha(binary),'sbf':str(SBF),'sbf_sha256':sha(SBF),'compile_log':str(LOG),'compile_log_sha256':sha(LOG),'registered':names,'results':[],'command_flags':['--exact','--include-ignored','--nocapture','--test-threads=1']}
assert report['candidate_tree']=='6621d5edd799f68ce0864f740ddc6da22e01c701'
assert report['sbf_sha256']=='527b000d136ed3ed50dc5bc131d571a8388ebce57ce542ce2225dea693fca180'
def save(): (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for i,n in enumerate(names):
 path=out/f'test-{i:04d}.log';start=time.monotonic()
 command=[binary,n,'--exact','--include-ignored','--nocapture','--test-threads=1']
 with path.open('w') as stream:
  p=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=p.wait(timeout=1800)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);p.wait();stream.write('\nSUPPLEMENTAL TEST TIMEOUT\n');code=124
 text=path.read_text(errors='replace')
 passed=code==0 and re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;',text) is not None
 report['results'].append({'name':n,'passed':passed,'exit_code':code,'seconds':round(time.monotonic()-start,3),'log':str(path),'log_sha256':sha(path)})
 save();print(TARGET,n,'PASS' if passed else 'FAIL',flush=True)
subprocess.run(['git','diff','--exit-code','--quiet'],cwd=ROOT,check=True)
assert subprocess.check_output(['git','write-tree'],cwd=ROOT,text=True).strip()==report['candidate_tree']
assert sha(SBF)==report['sbf_sha256']
report['status']='complete';report['passed']=sum(r['passed'] for r in report['results']);report['failed']=len(names)-report['passed'];save()
print(json.dumps({'target':TARGET,'passed':report['passed'],'failed':report['failed'],'total':len(names)}),flush=True)
sys.exit(0 if report['failed']==0 else 1)
